# Моя цель — iPhone-версия (SwiftUI)

Порт веб-приложения `tsel.html` на нативный iOS: цель и накопления, задачи, заметки,
напоминания, ИИ-помощник (Claude / OpenAI / Gemini / свой endpoint), голос.

Три стиля интерфейса (Вкладка «Оформление»): **Liquid Glass**, **iOS (классика)**,
**Material You** (5 цветов) × тема **светлая / тёмная / системная**.

## Структура

```
MyGoal/
  App/        MyGoalApp.swift            точка входа (@main)
  Models/     Models.swift               данные (Codable)
  Services/   Store.swift                состояние и логика (ObservableObject)
              AIService.swift            запросы к ИИ + настройки
              NotificationService.swift  локальные уведомления
              VoiceService.swift         озвучка и голосовой ввод
              Keychain.swift             хранение API-ключей
  Theme/      Theme.swift                палитры стилей
              Components.swift           карточки, кнопки, поля, Liquid Glass
  Views/      RootView / GoalView / TasksView / RemindersView / AssistantView / SettingsView
project.yml                              описание проекта для XcodeGen
```

## Сборка

**Вариант 1 — XcodeGen (проще всего, в т.ч. в облачных сборщиках):**
`brew install xcodegen && xcodegen` — создаст `MyGoal.xcodeproj`, затем открыть в Xcode.
В `project.yml` поменяй `PRODUCT_BUNDLE_IDENTIFIER` на свой.

**Вариант 2 — вручную:** Xcode → New Project → iOS App (SwiftUI, Swift), удали
`ContentView.swift`, перетащи папку `MyGoal/` в проект. В Info добавь
`NSMicrophoneUsageDescription` и `NSSpeechRecognitionUsageDescription`.

Минимальная iOS — 17. Настоящее стекло Liquid Glass — на iOS 26+ (Xcode 26);
на более старых версиях то же место занимает матовый материал.
