import SwiftUI

@main
struct MyGoalApp: App {
    @StateObject private var store = Store()
    @StateObject private var theme = ThemeManager()
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            RootContainer()
                .environmentObject(store)
                .environmentObject(theme)
                .onChange(of: phase) { _, new in
                    if new == .active { store.tick() }
                }
        }
    }
}
