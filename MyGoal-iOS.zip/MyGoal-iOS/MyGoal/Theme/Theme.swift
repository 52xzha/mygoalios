import SwiftUI
import UIKit

enum DesignStyle: String, CaseIterable, Identifiable {
    case liquidGlass, classic, material
    var id: String { rawValue }
    var title: String {
        switch self {
        case .liquidGlass: return "Liquid Glass"
        case .classic: return "iOS (классика)"
        case .material: return "Material You"
        }
    }
    var subtitle: String {
        switch self {
        case .liquidGlass: return "Стеклянные панели iOS 26. На старых iOS — матовое стекло."
        case .classic: return "Обычные плоские карточки, как в системных приложениях."
        case .material: return "Тональные цвета и скруглённые формы Material 3."
        }
    }
}

enum AppearanceMode: String, CaseIterable, Identifiable {
    case system, light, dark
    var id: String { rawValue }
    var title: String {
        switch self {
        case .system: return "Как в системе"
        case .light: return "Светлая"
        case .dark: return "Тёмная"
        }
    }
    var scheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}

enum SeedColor {
    static let all: [(id: String, name: String, hue: Double)] = [
        ("indigo", "Индиго", 0.68), ("teal", "Бирюза", 0.49), ("rose", "Роза", 0.94),
        ("orange", "Оранж", 0.07), ("green", "Зелёный", 0.35)
    ]
    static func hue(_ id: String) -> Double { all.first { $0.id == id }?.hue ?? 0.68 }
}

@MainActor
final class ThemeManager: ObservableObject {
    @Published var style: DesignStyle {
        didSet { UserDefaults.standard.set(style.rawValue, forKey: "ui_style") }
    }
    @Published var appearance: AppearanceMode {
        didSet { UserDefaults.standard.set(appearance.rawValue, forKey: "ui_appearance") }
    }
    @Published var seed: String {
        didSet { UserDefaults.standard.set(seed, forKey: "ui_seed") }
    }

    init() {
        let d = UserDefaults.standard
        style = DesignStyle(rawValue: d.string(forKey: "ui_style") ?? "") ?? .liquidGlass
        appearance = AppearanceMode(rawValue: d.string(forKey: "ui_appearance") ?? "") ?? .system
        seed = d.string(forKey: "ui_seed") ?? "indigo"
    }
}

private func hsb(_ h: Double, _ s: Double, _ b: Double) -> Color {
    Color(hue: h, saturation: s, brightness: b)
}

/// Палитра и форма под выбранный стиль и светлую/тёмную тему.
struct Theme {
    var style: DesignStyle
    var dark: Bool
    var seedHue: Double

    var bg = Color.clear
    var card = Color.clear
    var text = Color.primary
    var muted = Color.secondary
    var accent = Color.blue
    var onAccent = Color.white
    var accentContainer = Color.blue.opacity(0.15)
    var onAccentContainer = Color.blue
    var ok = Color.green
    var danger = Color.red
    var line = Color.gray.opacity(0.3)
    var field = Color.gray.opacity(0.15)
    var radius: CGFloat = 14

    init(style: DesignStyle, dark: Bool, seedHue h: Double) {
        self.style = style
        self.dark = dark
        self.seedHue = h

        switch style {
        case .classic:
            bg = Color(uiColor: .systemGroupedBackground)
            card = Color(uiColor: .secondarySystemGroupedBackground)
            text = Color(uiColor: .label)
            muted = Color(uiColor: .secondaryLabel)
            accent = Color(uiColor: .systemBlue)
            accentContainer = Color(uiColor: .systemBlue).opacity(0.15)
            onAccentContainer = Color(uiColor: .systemBlue)
            ok = Color(uiColor: .systemGreen)
            danger = Color(uiColor: .systemRed)
            line = Color(uiColor: .separator)
            field = Color(uiColor: .tertiarySystemFill)
            radius = 14

        case .liquidGlass:
            bg = .clear
            card = .clear
            text = Color(uiColor: .label)
            muted = Color(uiColor: .secondaryLabel)
            accent = Color(uiColor: .systemBlue)
            accentContainer = Color(uiColor: .systemBlue).opacity(0.2)
            onAccentContainer = Color(uiColor: .systemBlue)
            ok = Color(uiColor: .systemGreen)
            danger = Color(uiColor: .systemRed)
            line = Color.primary.opacity(0.15)
            field = Color.white.opacity(dark ? 0.1 : 0.4)
            radius = 26

        case .material:
            radius = 28
            onAccent = dark ? hsb(h, 0.8, 0.22) : .white
            if dark {
                bg = hsb(h, 0.20, 0.09)
                card = hsb(h, 0.22, 0.15)
                text = hsb(h, 0.06, 0.93)
                muted = hsb(h, 0.10, 0.70)
                accent = hsb(h, 0.35, 0.95)
                accentContainer = hsb(h, 0.55, 0.35)
                onAccentContainer = hsb(h, 0.20, 0.97)
                line = hsb(h, 0.20, 0.28)
                field = hsb(h, 0.25, 0.22)
                ok = hsb(0.36, 0.45, 0.85)
                danger = hsb(0.0, 0.40, 0.97)
            } else {
                bg = hsb(h, 0.03, 0.99)
                card = hsb(h, 0.07, 0.95)
                text = hsb(h, 0.20, 0.12)
                muted = hsb(h, 0.12, 0.40)
                accent = hsb(h, 0.75, 0.55)
                accentContainer = hsb(h, 0.22, 0.97)
                onAccentContainer = hsb(h, 0.80, 0.30)
                line = hsb(h, 0.12, 0.82)
                field = hsb(h, 0.12, 0.92)
                ok = hsb(0.36, 0.70, 0.50)
                danger = hsb(0.0, 0.70, 0.75)
            }
        }
    }
}

private struct ThemeKey: EnvironmentKey {
    static let defaultValue = Theme(style: .classic, dark: false, seedHue: 0.68)
}

extension EnvironmentValues {
    var theme: Theme {
        get { self[ThemeKey.self] }
        set { self[ThemeKey.self] = newValue }
    }
}
