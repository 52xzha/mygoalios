import SwiftUI

// MARK: Liquid Glass (iOS 26+) с запасным вариантом для старых iOS

extension View {
    @ViewBuilder
    func glassSurface(cornerRadius: CGFloat, interactive: Bool = false) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26, *) {
            self.glassEffect(interactive ? Glass.regular.interactive() : Glass.regular,
                             in: .rect(cornerRadius: cornerRadius))
        } else {
            glassFallback(cornerRadius: cornerRadius)
        }
        #else
        glassFallback(cornerRadius: cornerRadius)
        #endif
    }

    func glassFallback(cornerRadius: CGFloat) -> some View {
        self
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.25), lineWidth: 0.5)
            )
    }

    func themedField() -> some View { modifier(FieldStyle()) }
}

// MARK: Фон экрана

struct ThemedBackground: View {
    @Environment(\.theme) private var t

    var body: some View {
        switch t.style {
        case .liquidGlass:
            ZStack {
                LinearGradient(
                    colors: t.dark
                        ? [Color(hue: 0.68, saturation: 0.6, brightness: 0.25),
                           Color(hue: 0.80, saturation: 0.5, brightness: 0.15)]
                        : [Color(hue: 0.58, saturation: 0.35, brightness: 1.0),
                           Color(hue: 0.78, saturation: 0.30, brightness: 0.98)],
                    startPoint: .topLeading, endPoint: .bottomTrailing)
                Circle().fill(Color.pink.opacity(0.35)).frame(width: 260, height: 260)
                    .blur(radius: 70).offset(x: -120, y: -260)
                Circle().fill(Color.cyan.opacity(0.35)).frame(width: 300, height: 300)
                    .blur(radius: 80).offset(x: 140, y: 300)
            }
            .ignoresSafeArea()
        default:
            t.bg.ignoresSafeArea()
        }
    }
}

// MARK: Карточка

struct CardSurface: ViewModifier {
    @Environment(\.theme) private var t

    @ViewBuilder
    func body(content: Content) -> some View {
        switch t.style {
        case .liquidGlass:
            content.glassSurface(cornerRadius: t.radius)
        default:
            content.background(t.card, in: RoundedRectangle(cornerRadius: t.radius, style: .continuous))
        }
    }
}

struct ThemedCard<Content: View>: View {
    @Environment(\.theme) private var t
    let title: String?
    let content: Content

    init(_ title: String? = nil, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if let title {
                Text(title)
                    .font(t.style == .material ? .title3.weight(.medium) : .headline)
                    .foregroundStyle(t.text)
            }
            content
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .modifier(CardSurface())
    }
}

// MARK: Поле ввода

struct FieldStyle: ViewModifier {
    @Environment(\.theme) private var t

    func body(content: Content) -> some View {
        content
            .padding(12)
            .foregroundStyle(t.text)
            .background(t.field, in: RoundedRectangle(cornerRadius: t.style == .material ? 16 : 10,
                                                      style: .continuous))
    }
}

// MARK: Кнопки

enum ButtonKind { case filled, tonal, ghost, danger }

struct ThemedButtonStyle: ButtonStyle {
    @Environment(\.theme) private var t
    var kind: ButtonKind = .filled

    private var shape: AnyShape {
        t.style == .classic ? AnyShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                            : AnyShape(Capsule())
    }

    @ViewBuilder
    func makeBody(configuration: Configuration) -> some View {
        let label = configuration.label
            .font(.body.weight(.semibold))
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .frame(minHeight: 42)
        Group {
            switch kind {
            case .filled:
                label.foregroundStyle(t.onAccent).background(shape.fill(t.accent))
            case .tonal:
                label.foregroundStyle(t.onAccentContainer).background(shape.fill(t.accentContainer))
            case .ghost, .danger:
                let fg = kind == .danger ? t.danger : t.muted
                if t.style == .liquidGlass {
                    label.foregroundStyle(fg).glassSurface(cornerRadius: 22, interactive: true)
                } else {
                    label.foregroundStyle(fg).overlay(shape.stroke(t.line, lineWidth: 1))
                }
            }
        }
        .opacity(configuration.isPressed ? 0.7 : 1)
    }
}

// MARK: Полоса прогресса

struct ProgressBar: View {
    @Environment(\.theme) private var t
    var value: Double

    var body: some View {
        GeometryReader { g in
            ZStack(alignment: .leading) {
                Capsule().fill(t.line)
                Capsule().fill(t.style == .material ? t.accent : t.ok)
                    .frame(width: g.size.width * min(max(value, 0), 1))
            }
        }
        .frame(height: t.style == .material ? 12 : 14)
        .animation(.easeInOut(duration: 0.4), value: value)
    }
}

// MARK: Прокручиваемый экран

struct ScreenScroll<Content: View>: View {
    let anchorBottom: Bool
    let content: Content

    init(anchorBottom: Bool = false, @ViewBuilder content: () -> Content) {
        self.anchorBottom = anchorBottom
        self.content = content()
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 14) { content }
                .padding(16)
        }
        .scrollDismissesKeyboard(.interactively)
        .defaultScrollAnchor(anchorBottom ? .bottom : .top)
        .background { ThemedBackground() }
    }
}
