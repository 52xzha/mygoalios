import Foundation

struct SavingEntry: Codable, Identifiable {
    var id = UUID()
    var value: Double
    var date: Date
}

struct TaskItem: Codable, Identifiable {
    var id = UUID()
    var text: String
    var done = false
}

enum RepeatMode: String, Codable, CaseIterable, Identifiable {
    case once, daily, weekdays, weekly
    var id: String { rawValue }
    var title: String {
        switch self {
        case .once: return "Один раз"
        case .daily: return "Каждый день"
        case .weekdays: return "По будням"
        case .weekly: return "Раз в неделю"
        }
    }
}

struct Reminder: Codable, Identifiable {
    var id = UUID()
    var title: String
    var hour: Int
    var minute: Int
    var repeatMode: RepeatMode
    var date: Date
    var weekday: Int          // как в Calendar: 1 = воскресенье … 7 = суббота
    var prompt: String
    var done = false
    var last = ""             // дата последнего срабатывания yyyy-MM-dd
}

struct ChatMessage: Codable, Identifiable {
    var id = UUID()
    var role: String          // "user" | "assistant"
    var content: String
    var isError = false
}

struct GoalData: Codable {
    var goal = ""
    var target: Double = 0
    var currency = "BYN"
    var deadline: Date? = nil
    var notes = ""
    var tasks: [TaskItem] = []
    var history: [SavingEntry] = []
    var reminders: [Reminder] = []
    var chat: [ChatMessage] = []
}

func parseNumber(_ s: String) -> Double? {
    Double(s.replacingOccurrences(of: ",", with: ".").trimmingCharacters(in: .whitespaces))
}
