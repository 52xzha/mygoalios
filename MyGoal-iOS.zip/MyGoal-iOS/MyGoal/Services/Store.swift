import SwiftUI
import UIKit

struct AlertItem: Identifiable {
    let id = UUID()
    var text: String
}

/// Единый источник данных приложения (аналог объекта S из веб-версии).
@MainActor
final class Store: ObservableObject {
    private static let key = "tsel_v1"

    @Published var data: GoalData { didSet { persist() } }
    @Published var alerts: [AlertItem] = []
    @Published var isBusy = false
    @Published var ttsEnabled: Bool {
        didSet { UserDefaults.standard.set(ttsEnabled, forKey: "tts_on") }
    }

    let ai = AISettings()
    let voice = VoiceService()

    init() {
        if let raw = UserDefaults.standard.data(forKey: Store.key),
           let d = try? JSONDecoder().decode(GoalData.self, from: raw) {
            data = d
        } else {
            data = GoalData()
        }
        ttsEnabled = UserDefaults.standard.bool(forKey: "tts_on")
    }

    private func persist() {
        if let raw = try? JSONEncoder().encode(data) {
            UserDefaults.standard.set(raw, forKey: Store.key)
        }
    }

    // MARK: Накопления

    var saved: Double { data.history.reduce(0) { $0 + $1.value } }
    var progress: Double { data.target > 0 ? min(1, max(0, saved / data.target)) : 0 }

    func format(_ n: Double) -> String {
        n.formatted(.number.precision(.fractionLength(0...2)).locale(Locale(identifier: "ru_RU")))
    }

    var percentText: String {
        data.target > 0
            ? "\(Int((progress * 100).rounded()))% от \(format(data.target)) \(data.currency)"
            : "Укажи сумму цели выше"
    }

    var leftText: String {
        let t = data.target
        guard t > 0 else { return "" }
        let r = t - saved
        if r <= 0 { return "🎉 Цель достигнута!" }
        var s = "Осталось накопить: \(format(r)) \(data.currency)"
        if let d = data.deadline {
            let cal = Calendar.current
            let days = cal.dateComponents([.day], from: cal.startOfDay(for: Date()),
                                          to: cal.startOfDay(for: d)).day ?? 0
            if days > 0 {
                s += " · \(days) дн. · ~\(format(r / Double(days))) \(data.currency)/день"
            } else {
                s += " · срок прошёл"
            }
        }
        return s
    }

    @discardableResult
    func addMoney(sign: Double, text: String) -> Bool {
        guard let v = parseNumber(text), v > 0 else { return false }
        data.history.append(SavingEntry(value: sign * v, date: Date()))
        return true
    }

    // MARK: Задачи

    func addTask(_ text: String) {
        let v = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !v.isEmpty else { return }
        data.tasks.append(TaskItem(text: v))
    }

    func toggleTask(_ id: UUID) {
        if let i = data.tasks.firstIndex(where: { $0.id == id }) { data.tasks[i].done.toggle() }
    }

    func removeTask(_ id: UUID) { data.tasks.removeAll { $0.id == id } }

    // MARK: Напоминания

    func addReminder(_ r: Reminder) {
        data.reminders.append(r)
        NotificationService.schedule(r)
        tick()
    }

    func removeReminder(_ id: UUID) {
        if let r = data.reminders.first(where: { $0.id == id }) { NotificationService.cancel(r) }
        data.reminders.removeAll { $0.id == id }
    }

    private static func ymd(_ d: Date) -> String {
        let c = Calendar.current.dateComponents([.year, .month, .day], from: d)
        return String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
    }

    private func dueToday(_ r: Reminder, _ d: Date) -> Bool {
        if r.done { return false }
        let wd = Calendar.current.component(.weekday, from: d)
        switch r.repeatMode {
        case .once: return Calendar.current.isDate(r.date, inSameDayAs: d)
        case .daily: return true
        case .weekdays: return (2...6).contains(wd)
        case .weekly: return wd == r.weekday
        }
    }

    /// Проверка напоминаний, пока приложение открыто (вызывается раз в 15 с и при возврате в приложение).
    func tick() {
        let now = Date()
        let cal = Calendar.current
        let today = Store.ymd(now)
        let mins = cal.component(.hour, from: now) * 60 + cal.component(.minute, from: now)
        for i in data.reminders.indices {
            let r = data.reminders[i]
            guard dueToday(r, now) else { continue }
            let at = r.hour * 60 + r.minute
            if at > mins || mins - at > 30 { continue }
            if r.last == today { continue }
            data.reminders[i].last = today
            if r.repeatMode == .once { data.reminders[i].done = true }
            fire(r)
        }
    }

    private func fire(_ r: Reminder) {
        let msg = "Привет, выполни: " + r.title
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        let item = AlertItem(text: msg)
        alerts.append(item)
        guard !r.prompt.isEmpty, !ai.apiKey.isEmpty else { return }
        setAlert(item.id, msg + "\n\n…")
        Task {
            do {
                let ans = try await AIService.call(
                    messages: [AIMessage(role: "user", content: r.prompt)],
                    system: systemPrompt(), config: ai.config)
                setAlert(item.id, msg + "\n\n" + ans)
                data.chat.append(ChatMessage(role: "user", content: "(напоминание «\(r.title)») \(r.prompt)"))
                data.chat.append(ChatMessage(role: "assistant", content: ans))
                trimChat()
                if ttsEnabled { voice.speak(msg + ". " + ans) }
            } catch {
                setAlert(item.id, msg + "\n\nИИ не ответил: " + errorText(error))
            }
        }
    }

    private func setAlert(_ id: UUID, _ text: String) {
        if let i = alerts.firstIndex(where: { $0.id == id }) { alerts[i].text = text }
    }

    func dismissAlert(_ id: UUID) { alerts.removeAll { $0.id == id } }

    // MARK: ИИ-помощник

    func systemPrompt() -> String {
        let t = data.target
        let tasks = data.tasks.map { ($0.done ? "[x] " : "[ ] ") + $0.text }.joined(separator: "\n")
        let deadline = data.deadline?.formatted(date: .numeric, time: .omitted) ?? "не задан"
        return "Ты дружелюбный помощник по личным целям и накоплениям. Отвечай по-русски, коротко и по делу.\n"
            + "Данные пользователя:\n"
            + "Цель: " + (data.goal.isEmpty ? "не задана" : data.goal) + "\n"
            + "Нужная сумма: " + (t > 0 ? "\(format(t)) \(data.currency)" : "не задана") + "\n"
            + "Накоплено: \(format(saved)) \(data.currency)\n"
            + "Осталось: " + (t > 0 ? "\(format(max(0, t - saved))) \(data.currency)" : "—") + "\n"
            + "Срок: " + deadline + "\n"
            + "Сегодня: " + Date().formatted(date: .numeric, time: .omitted) + "\n"
            + "Задачи:\n" + (tasks.isEmpty ? "нет" : tasks) + "\n"
            + "Заметки: " + (data.notes.isEmpty ? "нет" : data.notes)
    }

    private func history() -> [AIMessage] {
        var msgs = data.chat.filter { !$0.isError }.map { AIMessage(role: $0.role, content: $0.content) }
        while let f = msgs.first, f.role == "assistant" { msgs.removeFirst() }
        return msgs
    }

    private func trimChat() {
        if data.chat.count > 30 { data.chat = Array(data.chat.suffix(30)) }
    }

    func errorText(_ error: Error) -> String {
        if error is URLError {
            return "не удалось подключиться (проверь ключ, endpoint и интернет)"
        }
        return error.localizedDescription
    }

    func send(_ text: String) async {
        let v = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !v.isEmpty, !isBusy else { return }
        data.chat.append(ChatMessage(role: "user", content: v))
        trimChat()
        isBusy = true
        defer { isBusy = false }
        do {
            let ans = try await AIService.call(messages: history(), system: systemPrompt(), config: ai.config)
            data.chat.append(ChatMessage(role: "assistant", content: ans))
            trimChat()
            if ttsEnabled { voice.speak(ans) }
        } catch {
            data.chat.removeLast()
            data.chat.append(ChatMessage(role: "assistant", content: "Ошибка: " + errorText(error), isError: true))
        }
    }

    func testKey() async -> String {
        do {
            let a = try await AIService.call(
                messages: [AIMessage(role: "user", content: "Ответь одним словом: работает")],
                system: "Отвечай коротко.", config: ai.config)
            return "Ключ работает. Ответ: " + String(a.prefix(80))
        } catch {
            return "Ошибка: " + errorText(error)
        }
    }

    func clearChat() { data.chat = [] }

    func resetAll() {
        NotificationService.cancelAll()
        data = GoalData()
    }
}
