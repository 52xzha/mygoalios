import Foundation
import UserNotifications

/// Системные локальные уведомления: работают, даже когда приложение закрыто.
enum NotificationService {
    static func requestPermission() async -> Bool {
        (try? await UNUserNotificationCenter.current()
            .requestAuthorization(options: [.alert, .sound, .badge])) ?? false
    }

    private static func ids(_ r: Reminder) -> [String] {
        [r.id.uuidString] + (2...6).map { "\(r.id.uuidString)-\($0)" }
    }

    static func cancel(_ r: Reminder) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ids(r))
    }

    static func cancelAll() {
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
    }

    static func schedule(_ r: Reminder) {
        cancel(r)
        let content = UNMutableNotificationContent()
        content.title = "Моя цель"
        content.body = "Привет, выполни: " + r.title
        content.sound = .default

        func add(_ id: String, _ comps: DateComponents, repeats: Bool) {
            let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: repeats)
            UNUserNotificationCenter.current().add(
                UNNotificationRequest(identifier: id, content: content, trigger: trigger))
        }

        let cal = Calendar.current
        var base = DateComponents()
        base.hour = r.hour
        base.minute = r.minute

        switch r.repeatMode {
        case .once:
            var c = cal.dateComponents([.year, .month, .day], from: r.date)
            c.hour = r.hour
            c.minute = r.minute
            if let d = cal.date(from: c), d > Date() { add(r.id.uuidString, c, repeats: false) }
        case .daily:
            add(r.id.uuidString, base, repeats: true)
        case .weekdays:
            for wd in 2...6 {
                var c = base
                c.weekday = wd
                add("\(r.id.uuidString)-\(wd)", c, repeats: true)
            }
        case .weekly:
            var c = base
            c.weekday = r.weekday
            add(r.id.uuidString, c, repeats: true)
        }
    }
}
