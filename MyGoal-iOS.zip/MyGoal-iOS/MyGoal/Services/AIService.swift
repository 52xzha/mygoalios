import Foundation

enum AIProvider: String, CaseIterable, Identifiable {
    case anthropic, openai, gemini, custom
    var id: String { rawValue }
    var title: String {
        switch self {
        case .anthropic: return "Claude (Anthropic)"
        case .openai: return "ChatGPT (OpenAI)"
        case .gemini: return "Gemini (Google)"
        case .custom: return "Свой endpoint (OpenAI-совместимый)"
        }
    }
    var defaultModel: String {
        switch self {
        case .anthropic: return "claude-sonnet-5-5"
        case .openai: return "gpt-4o-mini"
        case .gemini: return "gemini-2.0-flash"
        case .custom: return ""
        }
    }
}

struct AIMessage { let role: String; let content: String }
struct AIConfig { let provider: AIProvider; let key: String; let model: String; let endpoint: String }
struct AIError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

@MainActor
final class AISettings: ObservableObject {
    @Published var provider: AIProvider {
        didSet {
            UserDefaults.standard.set(provider.rawValue, forKey: "ai_provider")
            loadCurrent()
        }
    }
    @Published var apiKey = "" {
        didSet { if !loading { Keychain.set(apiKey, for: "key_" + provider.rawValue) } }
    }
    @Published var model = "" {
        didSet { if !loading { UserDefaults.standard.set(model, forKey: "ai_model_" + provider.rawValue) } }
    }
    @Published var endpoint: String {
        didSet { UserDefaults.standard.set(endpoint, forKey: "ai_endpoint") }
    }
    private var loading = false

    init() {
        provider = AIProvider(rawValue: UserDefaults.standard.string(forKey: "ai_provider") ?? "") ?? .anthropic
        endpoint = UserDefaults.standard.string(forKey: "ai_endpoint") ?? ""
        loadCurrent()
    }

    private func loadCurrent() {
        loading = true
        apiKey = Keychain.get("key_" + provider.rawValue) ?? ""
        model = UserDefaults.standard.string(forKey: "ai_model_" + provider.rawValue) ?? provider.defaultModel
        loading = false
    }

    var config: AIConfig {
        AIConfig(provider: provider, key: apiKey,
                 model: model.isEmpty ? provider.defaultModel : model, endpoint: endpoint)
    }
}

enum AIService {
    static func call(messages: [AIMessage], system: String, config c: AIConfig) async throws -> String {
        guard !c.key.isEmpty else { throw AIError(message: "Укажи API-ключ в настройках ИИ.") }
        guard !c.model.isEmpty else { throw AIError(message: "Укажи название модели.") }

        switch c.provider {
        case .anthropic:
            let json = try await post("https://api.anthropic.com/v1/messages",
                headers: ["x-api-key": c.key, "anthropic-version": "2023-06-01"],
                body: ["model": c.model, "max_tokens": 1024, "system": system,
                       "messages": messages.map { ["role": $0.role, "content": $0.content] }])
            let parts = json["content"] as? [[String: Any]] ?? []
            return parts.compactMap { $0["text"] as? String }.joined()

        case .gemini:
            let model = c.model.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? c.model
            let json = try await post(
                "https://generativelanguage.googleapis.com/v1beta/models/\(model):generateContent",
                headers: ["x-goog-api-key": c.key],
                body: ["systemInstruction": ["parts": [["text": system]]],
                       "contents": messages.map {
                           ["role": $0.role == "assistant" ? "model" : "user",
                            "parts": [["text": $0.content]]] as [String: Any]
                       }])
            let cand = (json["candidates"] as? [[String: Any]])?.first
            let parts = (cand?["content"] as? [String: Any])?["parts"] as? [[String: Any]] ?? []
            return parts.compactMap { $0["text"] as? String }.joined()

        case .openai, .custom:
            var base = c.provider == .openai ? "https://api.openai.com/v1" : c.endpoint
            while base.hasSuffix("/") { base.removeLast() }
            guard !base.isEmpty else { throw AIError(message: "Укажи endpoint.") }
            let url = base.hasSuffix("/chat/completions") ? base : base + "/chat/completions"
            var msgs: [[String: String]] = [["role": "system", "content": system]]
            msgs += messages.map { ["role": $0.role, "content": $0.content] }
            let json = try await post(url, headers: ["authorization": "Bearer " + c.key],
                                      body: ["model": c.model, "messages": msgs])
            let choice = (json["choices"] as? [[String: Any]])?.first
            return (choice?["message"] as? [String: Any])?["content"] as? String ?? ""
        }
    }

    private static func post(_ url: String, headers: [String: String], body: [String: Any]) async throws -> [String: Any] {
        guard let u = URL(string: url) else { throw AIError(message: "Некорректный адрес.") }
        var req = URLRequest(url: u)
        req.httpMethod = "POST"
        req.timeoutInterval = 60
        req.setValue("application/json", forHTTPHeaderField: "content-type")
        for (k, v) in headers { req.setValue(v, forHTTPHeaderField: k) }
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, resp) = try await URLSession.shared.data(for: req)
        let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
        if let code = (resp as? HTTPURLResponse)?.statusCode, !(200..<300).contains(code) {
            var msg = "HTTP \(code)"
            if let e = json["error"] as? [String: Any], let m = e["message"] as? String { msg = m }
            else if let s = json["error"] as? String { msg = s }
            throw AIError(message: msg)
        }
        return json
    }
}
