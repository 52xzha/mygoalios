import AVFoundation
import Speech

/// Озвучка ответов и голосовой ввод на нативных API iOS.
@MainActor
final class VoiceService: NSObject, ObservableObject {
    @Published var listening = false

    private let synth = AVSpeechSynthesizer()
    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "ru-RU"))
    private let engine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?

    func speak(_ text: String) {
        synth.stopSpeaking(at: .immediate)
        let u = AVSpeechUtterance(string: String(text.prefix(2000)))
        u.voice = AVSpeechSynthesisVoice(language: "ru-RU")
        synth.speak(u)
    }

    func toggle(onText: @escaping (String) -> Void, onError: @escaping (String) -> Void) {
        if listening { finishListening(); return }
        SFSpeechRecognizer.requestAuthorization { status in
            Task { @MainActor in
                guard status == .authorized else {
                    onError("Нет доступа к распознаванию речи. Разреши его в Настройках iPhone.")
                    return
                }
                AVAudioApplication.requestRecordPermission { granted in
                    Task { @MainActor in
                        guard granted else {
                            onError("Нет доступа к микрофону. Разреши его в Настройках iPhone.")
                            return
                        }
                        self.start(onText: onText, onError: onError)
                    }
                }
            }
        }
    }

    private func start(onText: @escaping (String) -> Void, onError: @escaping (String) -> Void) {
        guard let recognizer, recognizer.isAvailable else {
            onError("Распознавание речи сейчас недоступно.")
            return
        }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.record, mode: .measurement, options: .duckOthers)
            try session.setActive(true, options: .notifyOthersOnDeactivation)

            let req = SFSpeechAudioBufferRecognitionRequest()
            req.shouldReportPartialResults = false
            request = req

            let input = engine.inputNode
            let format = input.outputFormat(forBus: 0)
            input.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in
                req.append(buffer)
            }
            engine.prepare()
            try engine.start()
            listening = true

            task = recognizer.recognitionTask(with: req) { [weak self] result, error in
                Task { @MainActor in
                    guard let self, self.task != nil else { return }
                    if let result, result.isFinal {
                        let text = result.bestTranscription.formattedString
                        self.cleanup()
                        if text.isEmpty { onError("Речь не распознана. Скажи ещё раз.") } else { onText(text) }
                    } else if error != nil {
                        self.cleanup()
                        onError("Речь не распознана. Скажи ещё раз.")
                    }
                }
            }
        } catch {
            cleanup()
            onError("Ошибка микрофона: \(error.localizedDescription)")
        }
    }

    /// Пользователь нажал «стоп»: заканчиваем запись, дожидаемся результата.
    private func finishListening() {
        if engine.isRunning {
            engine.stop()
            engine.inputNode.removeTap(onBus: 0)
        }
        request?.endAudio()
        listening = false
    }

    private func cleanup() {
        if engine.isRunning {
            engine.stop()
            engine.inputNode.removeTap(onBus: 0)
        }
        task?.cancel()
        task = nil
        request = nil
        listening = false
    }
}
