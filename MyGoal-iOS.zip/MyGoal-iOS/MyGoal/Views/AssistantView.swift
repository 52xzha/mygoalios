import SwiftUI

struct AssistantView: View {
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var t
    @State private var msg = ""
    @State private var keyStatus = ""
    @State private var showSettings = false

    private func send() {
        let text = msg
        msg = ""
        Task { await store.send(text) }
    }

    var body: some View {
        VStack(spacing: 14) {
            ThemedCard("🤖 Помощник") {
                DisclosureGroup("Настройки ИИ", isExpanded: $showSettings) {
                    AISettingsFields(ai: store.ai, status: $keyStatus)
                        .padding(.top, 8)
                }
                .foregroundStyle(t.text)

                ForEach(store.data.chat) { m in
                    Bubble(message: m)
                }
                if store.isBusy { Bubble(message: ChatMessage(role: "assistant", content: "…")) }

                HStack {
                    TextField("Спроси: сколько осталось?", text: $msg)
                        .themedField()
                        .submitLabel(.send)
                        .onSubmit(send)
                    MicButton(voice: store.voice, onText: { text in
                        msg = text
                        send()
                    }, onError: { err in
                        store.data.chat.append(ChatMessage(role: "assistant", content: err, isError: true))
                    })
                    Button(action: send) { Image(systemName: "arrow.up") }
                        .buttonStyle(ThemedButtonStyle(kind: .filled))
                        .disabled(store.isBusy)
                }
                Toggle("Озвучивать ответы", isOn: $store.ttsEnabled).foregroundStyle(t.muted)
                Button("Очистить чат") { store.clearChat() }
                    .buttonStyle(ThemedButtonStyle(kind: .ghost))
            }
        }
    }
}

struct AISettingsFields: View {
    @EnvironmentObject private var store: Store
    @ObservedObject var ai: AISettings
    @Binding var status: String
    @Environment(\.theme) private var t

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Picker("Сервис", selection: $ai.provider) {
                ForEach(AIProvider.allCases) { Text($0.title).tag($0) }
            }
            .pickerStyle(.menu)
            SecureField("API-ключ", text: $ai.apiKey)
                .textInputAutocapitalization(.never).autocorrectionDisabled()
                .themedField()
            TextField("Модель", text: $ai.model)
                .textInputAutocapitalization(.never).autocorrectionDisabled()
                .themedField()
            if ai.provider == .custom {
                TextField("Endpoint, например https://example.com/v1", text: $ai.endpoint)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                    .keyboardType(.URL)
                    .themedField()
            }
            Button("Проверить ключ") {
                status = "Проверяю…"
                Task { status = await store.testKey() }
            }
            .buttonStyle(ThemedButtonStyle(kind: .ghost))
            if !status.isEmpty { Text(status).font(.footnote).foregroundStyle(t.muted) }
            Text("Вход через аккаунт невозможен, нужен API-ключ. Он хранится в связке ключей (Keychain) на этом устройстве и отправляется только выбранному сервису.")
                .font(.footnote).foregroundStyle(t.muted)
        }
    }
}

struct MicButton: View {
    @ObservedObject var voice: VoiceService
    @Environment(\.theme) private var t
    let onText: (String) -> Void
    let onError: (String) -> Void

    var body: some View {
        Button {
            voice.toggle(onText: onText, onError: onError)
        } label: {
            Image(systemName: voice.listening ? "stop.fill" : "mic.fill")
                .foregroundStyle(voice.listening ? t.danger : t.muted)
        }
        .buttonStyle(ThemedButtonStyle(kind: .ghost))
    }
}

struct Bubble: View {
    @Environment(\.theme) private var t
    let message: ChatMessage

    var body: some View {
        let isUser = message.role == "user"
        HStack {
            if isUser { Spacer(minLength: 40) }
            Text(message.content)
                .padding(.horizontal, 12).padding(.vertical, 8)
                .foregroundStyle(message.isError ? t.danger : (isUser ? t.onAccent : t.text))
                .background(isUser ? t.accent : (message.isError ? Color.clear : t.field),
                            in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            if !isUser { Spacer(minLength: 40) }
        }
    }
}
