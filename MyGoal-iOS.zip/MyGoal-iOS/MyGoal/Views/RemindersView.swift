import SwiftUI

struct RemindersView: View {
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var t

    @State private var title = ""
    @State private var time = Calendar.current.date(bySettingHour: 9, minute: 0, second: 0, of: Date()) ?? Date()
    @State private var mode: RepeatMode = .once
    @State private var date = Date()
    @State private var weekday = Calendar.current.component(.weekday, from: Date())
    @State private var prompt = ""
    @State private var permissionNote = ""

    private func add() {
        let v = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !v.isEmpty else { return }
        let c = Calendar.current.dateComponents([.hour, .minute], from: time)
        store.addReminder(Reminder(
            title: v, hour: c.hour ?? 9, minute: c.minute ?? 0, repeatMode: mode,
            date: date, weekday: weekday,
            prompt: prompt.trimmingCharacters(in: .whitespacesAndNewlines)))
        title = ""
        prompt = ""
        Task { _ = await NotificationService.requestPermission() }
    }

    private func repText(_ r: Reminder) -> String {
        switch r.repeatMode {
        case .once: return "один раз, " + r.date.formatted(date: .numeric, time: .omitted)
        case .daily: return "каждый день"
        case .weekdays: return "по будням"
        case .weekly: return "каждую неделю (\(Calendar.current.weekdaySymbols[max(0, min(6, r.weekday - 1))]))"
        }
    }

    var body: some View {
        VStack(spacing: 14) {
            ThemedCard("⏰ Новое напоминание") {
                TextField("О чём напомнить? (например: отложить 10 BYN)", text: $title).themedField()
                DatePicker("Время", selection: $time, displayedComponents: .hourAndMinute)
                    .foregroundStyle(t.text)
                Picker("Повтор", selection: $mode) {
                    ForEach(RepeatMode.allCases) { Text($0.title).tag($0) }
                }
                .pickerStyle(.menu)
                if mode == .once {
                    DatePicker("Дата", selection: $date, displayedComponents: .date)
                        .foregroundStyle(t.text)
                }
                if mode == .weekly {
                    Picker("День недели", selection: $weekday) {
                        ForEach(1...7, id: \.self) { Text(Calendar.current.weekdaySymbols[$0 - 1]).tag($0) }
                    }
                    .pickerStyle(.menu)
                }
                TextField("Запрос к ИИ в это время (необязательно)", text: $prompt).themedField()
                HStack {
                    Button("Добавить", action: add).buttonStyle(ThemedButtonStyle(kind: .filled))
                    Button("Разрешить уведомления") {
                        Task {
                            let ok = await NotificationService.requestPermission()
                            permissionNote = ok ? "Уведомления разрешены."
                                                : "Уведомления выключены. Включи их в Настройках iPhone."
                        }
                    }
                    .buttonStyle(ThemedButtonStyle(kind: .ghost))
                }
                if !permissionNote.isEmpty {
                    Text(permissionNote).font(.footnote).foregroundStyle(t.muted)
                }
                Text("Уведомления приходят, даже когда приложение закрыто. Запрос к ИИ отправляется, когда приложение открыто в нужное время (или при открытии в течение 30 минут после).")
                    .font(.footnote).foregroundStyle(t.muted)
            }

            ThemedCard("Список") {
                if store.data.reminders.isEmpty {
                    Text("Напоминаний пока нет.").foregroundStyle(t.muted)
                }
                ForEach(store.data.reminders) { r in
                    HStack(alignment: .top) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(String(format: "%02d:%02d · ", r.hour, r.minute) + r.title)
                                .fontWeight(.semibold)
                                .strikethrough(r.done)
                                .foregroundStyle(r.done ? t.muted : t.text)
                            Text(repText(r) + (r.prompt.isEmpty ? "" : " · с запросом к ИИ") + (r.done ? " · выполнено" : ""))
                                .font(.footnote).foregroundStyle(t.muted)
                        }
                        Spacer()
                        Button { store.removeReminder(r.id) } label: {
                            Image(systemName: "xmark").foregroundStyle(t.danger)
                        }
                        .buttonStyle(.plain)
                    }
                    Divider().overlay(t.line)
                }
            }
        }
    }
}
