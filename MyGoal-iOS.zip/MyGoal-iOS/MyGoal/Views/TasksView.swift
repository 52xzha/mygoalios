import SwiftUI

struct TasksView: View {
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var t
    @State private var newTask = ""

    private func add() {
        store.addTask(newTask)
        newTask = ""
    }

    var body: some View {
        VStack(spacing: 14) {
            ThemedCard("Задачи") {
                HStack {
                    TextField("Новая задача", text: $newTask)
                        .themedField()
                        .submitLabel(.done)
                        .onSubmit(add)
                    Button("Добавить", action: add).buttonStyle(ThemedButtonStyle(kind: .filled))
                }
                ForEach(store.data.tasks) { task in
                    HStack(spacing: 10) {
                        Button { store.toggleTask(task.id) } label: {
                            Image(systemName: task.done ? "checkmark.circle.fill" : "circle")
                                .font(.title3)
                                .foregroundStyle(task.done ? t.ok : t.muted)
                        }
                        .buttonStyle(.plain)
                        Text(task.text)
                            .strikethrough(task.done)
                            .foregroundStyle(task.done ? t.muted : t.text)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        Button { store.removeTask(task.id) } label: {
                            Image(systemName: "xmark").foregroundStyle(t.danger)
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.vertical, 4)
                    Divider().overlay(t.line)
                }
            }

            ThemedCard("Заметки") {
                ZStack(alignment: .topLeading) {
                    if store.data.notes.isEmpty {
                        Text("Всё, что хочется запомнить…")
                            .foregroundStyle(t.muted)
                            .padding(.horizontal, 17).padding(.vertical, 20)
                    }
                    TextEditor(text: $store.data.notes)
                        .scrollContentBackground(.hidden)
                        .frame(minHeight: 140)
                        .padding(8)
                        .foregroundStyle(t.text)
                }
                .background(t.field, in: RoundedRectangle(cornerRadius: t.style == .material ? 16 : 10,
                                                          style: .continuous))
            }
        }
    }
}
