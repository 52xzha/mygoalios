import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var theme: ThemeManager
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var t
    @State private var confirmReset = false

    var body: some View {
        VStack(spacing: 14) {
            ThemedCard("Стиль интерфейса") {
                ForEach(DesignStyle.allCases) { s in
                    Button { theme.style = s } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(s.title).foregroundStyle(t.text)
                                Text(s.subtitle).font(.caption).foregroundStyle(t.muted)
                                    .multilineTextAlignment(.leading)
                            }
                            Spacer()
                            if theme.style == s {
                                Image(systemName: "checkmark.circle.fill").foregroundStyle(t.accent)
                            }
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    Divider().overlay(t.line)
                }
            }

            ThemedCard("Тема") {
                Picker("Тема", selection: $theme.appearance) {
                    ForEach(AppearanceMode.allCases) { Text($0.title).tag($0) }
                }
                .pickerStyle(.segmented)

                if theme.style == .material {
                    Text("Цвет Material You").font(.footnote).foregroundStyle(t.muted)
                    HStack(spacing: 14) {
                        ForEach(SeedColor.all, id: \.id) { c in
                            Button { theme.seed = c.id } label: {
                                Circle()
                                    .fill(Color(hue: c.hue, saturation: 0.7, brightness: 0.8))
                                    .frame(width: 38, height: 38)
                                    .overlay(
                                        Image(systemName: "checkmark").foregroundStyle(.white)
                                            .opacity(theme.seed == c.id ? 1 : 0))
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel(c.name)
                        }
                    }
                }
            }

            ThemedCard("Данные") {
                Button("Стереть всё") { confirmReset = true }
                    .buttonStyle(ThemedButtonStyle(kind: .danger))
                Text("Данные хранятся только на этом устройстве.")
                    .font(.footnote).foregroundStyle(t.muted)
            }
        }
        .confirmationDialog("Стереть все данные?", isPresented: $confirmReset, titleVisibility: .visible) {
            Button("Стереть", role: .destructive) { store.resetAll() }
            Button("Отмена", role: .cancel) {}
        }
    }
}
