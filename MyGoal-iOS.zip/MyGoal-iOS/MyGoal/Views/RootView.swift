import SwiftUI

/// Применяет выбранную тему (светлая/тёмная/системная), затем строит палитру.
struct RootContainer: View {
    @EnvironmentObject private var theme: ThemeManager

    var body: some View {
        ThemedRoot().preferredColorScheme(theme.appearance.scheme)
    }
}

struct ThemedRoot: View {
    @EnvironmentObject private var theme: ThemeManager
    @EnvironmentObject private var store: Store
    @Environment(\.colorScheme) private var scheme
    private let timer = Timer.publish(every: 15, on: .main, in: .common).autoconnect()

    var body: some View {
        let t = Theme(style: theme.style, dark: scheme == .dark, seedHue: SeedColor.hue(theme.seed))
        MainTabs()
            .environment(\.theme, t)
            .tint(t.accent)
            .overlay(alignment: .top) {
                VStack(spacing: 8) {
                    ForEach(store.alerts) { a in
                        AlertBanner(item: a).environment(\.theme, t)
                    }
                }
                .padding(.horizontal, 12)
                .animation(.easeInOut, value: store.alerts.count)
            }
            .onReceive(timer) { _ in store.tick() }
            .onAppear { store.tick() }
    }
}

enum AppTab: Int, CaseIterable, Identifiable {
    case goal, tasks, reminders, assistant, settings
    var id: Int { rawValue }
    var title: String {
        switch self {
        case .goal: return "Цель"
        case .tasks: return "Задачи"
        case .reminders: return "Напоминания"
        case .assistant: return "Помощник"
        case .settings: return "Оформление"
        }
    }
    var icon: String {
        switch self {
        case .goal: return "target"
        case .tasks: return "checklist"
        case .reminders: return "bell"
        case .assistant: return "sparkles"
        case .settings: return "paintpalette"
        }
    }
}

struct MainTabs: View {
    @Environment(\.theme) private var t
    @State private var tab: AppTab = .goal

    var body: some View {
        if t.style == .material {
            // Material: своя нижняя навигация с «таблеткой» выбранного пункта
            VStack(spacing: 0) {
                page(tab)
                MaterialBar(tab: $tab)
            }
            .background(t.bg.ignoresSafeArea())
        } else {
            // iOS / Liquid Glass: системный TabView (на iOS 26 панель сама становится стеклянной)
            TabView(selection: $tab) {
                ForEach(AppTab.allCases) { item in
                    page(item)
                        .tabItem { Label(item.title, systemImage: item.icon) }
                        .tag(item)
                }
            }
        }
    }

    @ViewBuilder
    private func page(_ item: AppTab) -> some View {
        NavigationStack {
            ScreenScroll(anchorBottom: false) {
                switch item {
                case .goal: GoalView()
                case .tasks: TasksView()
                case .reminders: RemindersView()
                case .assistant: AssistantView()
                case .settings: SettingsView()
                }
            }
            .navigationTitle(item.title)
            .navigationBarTitleDisplayMode(t.style == .material ? .inline : .large)
        }
    }
}

struct MaterialBar: View {
    @Environment(\.theme) private var t
    @Binding var tab: AppTab

    var body: some View {
        HStack {
            ForEach(AppTab.allCases) { item in
                Button { tab = item } label: {
                    VStack(spacing: 4) {
                        Image(systemName: item.icon)
                            .font(.system(size: 20))
                            .frame(width: 64, height: 32)
                            .background(tab == item ? t.accentContainer : Color.clear, in: Capsule())
                        Text(item.title).font(.caption2)
                    }
                    .frame(maxWidth: .infinity)
                    .foregroundStyle(tab == item ? t.text : t.muted)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.top, 12)
        .padding(.bottom, 8)
        .background(t.card.ignoresSafeArea(edges: .bottom))
    }
}

struct AlertBanner: View {
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var t
    let item: AlertItem

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Text(item.text)
                .foregroundStyle(t.onAccent)
                .frame(maxWidth: .infinity, alignment: .leading)
            Button("Ок") { store.dismissAlert(item.id) }
                .buttonStyle(.plain)
                .padding(.horizontal, 10).padding(.vertical, 6)
                .background(Color.white.opacity(0.2), in: Capsule())
                .foregroundStyle(t.onAccent)
        }
        .padding(14)
        .background(t.accent, in: RoundedRectangle(cornerRadius: min(t.radius, 20), style: .continuous))
        .shadow(color: .black.opacity(0.25), radius: 12, y: 6)
        .transition(.move(edge: .top).combined(with: .opacity))
    }
}
