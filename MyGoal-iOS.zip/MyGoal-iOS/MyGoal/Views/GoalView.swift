import SwiftUI

struct GoalView: View {
    @EnvironmentObject private var store: Store
    @Environment(\.theme) private var t
    @State private var targetText = ""
    @State private var amt = ""

    private let currencies = ["BYN", "RUB", "USD", "EUR"]

    private var deadlineOn: Binding<Bool> {
        Binding(get: { store.data.deadline != nil },
                set: { store.data.deadline = $0 ? Date().addingTimeInterval(30 * 86400) : nil })
    }
    private var deadlineDate: Binding<Date> {
        Binding(get: { store.data.deadline ?? Date() }, set: { store.data.deadline = $0 })
    }

    var body: some View {
        VStack(spacing: 14) {
            ThemedCard("Цель") {
                TextField("Что хочу? (например: ноутбук)", text: $store.data.goal).themedField()
                HStack {
                    TextField("Сколько нужно денег", text: $targetText)
                        .keyboardType(.decimalPad)
                        .themedField()
                    Picker("Валюта", selection: $store.data.currency) {
                        ForEach(currencies, id: \.self) { Text($0).tag($0) }
                    }
                    .pickerStyle(.menu)
                }
                Toggle("Указать срок", isOn: deadlineOn).foregroundStyle(t.text)
                if store.data.deadline != nil {
                    DatePicker("Дата", selection: deadlineDate, displayedComponents: .date)
                        .foregroundStyle(t.text)
                }
                if !store.leftText.isEmpty {
                    Text(store.leftText).font(.footnote).foregroundStyle(t.muted)
                }
            }

            ThemedCard("Накоплено") {
                Text("\(store.format(store.saved)) \(store.data.currency)")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundStyle(t.text)
                ProgressBar(value: store.progress)
                Text(store.percentText).font(.footnote).foregroundStyle(t.muted)
                TextField("Сумма", text: $amt).keyboardType(.decimalPad).themedField()
                HStack {
                    Button { if store.addMoney(sign: 1, text: amt) { amt = "" } } label: {
                        Text("＋ Добавить").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(ThemedButtonStyle(kind: .filled))
                    Button { if store.addMoney(sign: -1, text: amt) { amt = "" } } label: {
                        Text("− Снять").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(ThemedButtonStyle(kind: .ghost))
                }
                ForEach(Array(store.data.history.suffix(10).reversed())) { h in
                    HStack {
                        Text((h.value >= 0 ? "+" : "") + store.format(h.value))
                            .fontWeight(.semibold)
                            .foregroundStyle(h.value >= 0 ? t.ok : t.danger)
                        Text(h.date.formatted(date: .numeric, time: .omitted))
                            .font(.footnote).foregroundStyle(t.muted)
                        Spacer()
                    }
                    Divider().overlay(t.line)
                }
            }
        }
        .onAppear {
            targetText = store.data.target > 0 ? store.format(store.data.target).replacingOccurrences(of: "\u{00A0}", with: "") : ""
        }
        .onChange(of: targetText) { _, new in
            store.data.target = parseNumber(new.replacingOccurrences(of: "\u{00A0}", with: "")) ?? 0
        }
    }
}
